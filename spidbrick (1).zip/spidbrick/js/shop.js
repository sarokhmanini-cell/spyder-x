/* Shop page: filters, search, sorting */
(async function () {
  "use strict";
  const SB = window.SB;
  SBLayout.init("shop");

  const grid = document.getElementById("grid");
  const countEl = document.getElementById("count");
  const catBox = document.getElementById("cats");
  const sizeSel = document.getElementById("size");
  const sortSel = document.getElementById("sort");
  const search = document.getElementById("q");
  const inStock = document.getElementById("inStock");

  let all = [];
  try {
    all = await SB.getCatalog();
  } catch (e) {
    grid.innerHTML = '<div class="empty">تعذّر تحميل المنتجات. افتح الموقع عبر GitHub Pages أو خادم محلي (انظر README).</div>';
    return;
  }

  let cat = SB.getParam("cat") || "all";
  if (cat !== "all" && !SB.CATEGORIES[cat]) cat = "all";

  const cats = [["all", "الكل"]].concat(Object.entries(SB.CATEGORIES));
  catBox.innerHTML = cats.map(([k, label]) =>
    `<button type="button" class="chip" data-cat="${k}">${label}</button>`).join("");

  sizeSel.innerHTML = '<option value="">كل المقاسات</option>' +
    SB.SIZES.map((s) => `<option value="${s}">${s}</option>`).join("");

  function apply() {
    let list = all.slice();
    if (cat !== "all") list = list.filter((p) => p.category === cat);

    const size = sizeSel.value;
    if (size) list = list.filter((p) => SB.stockFor(p, size) > 0);
    if (inStock.checked) list = list.filter((p) => SB.stockTotal(p) > 0);

    const term = search.value.trim().toLowerCase();
    if (term) {
      list = list.filter((p) => (p.name + " " + (p.description || "")).toLowerCase().includes(term));
    }

    switch (sortSel.value) {
      case "priceAsc": list.sort((a, b) => SB.unitPrice(a) - SB.unitPrice(b)); break;
      case "priceDesc": list.sort((a, b) => SB.unitPrice(b) - SB.unitPrice(a)); break;
      case "sale": list.sort((a, b) => Number(SB.onSale(b)) - Number(SB.onSale(a))); break;
      default: list.sort((a, b) => String(b.createdAt || "").localeCompare(String(a.createdAt || "")));
    }

    grid.innerHTML = list.length
      ? list.map((p) => SB.cardHTML(p)).join("")
      : '<div class="empty">لا توجد منتجات تطابق اختيارك.</div>';
    countEl.textContent = list.length + " منتج";

    catBox.querySelectorAll(".chip").forEach((b) => b.classList.toggle("on", b.dataset.cat === cat));
  }

  catBox.addEventListener("click", (e) => {
    const b = e.target.closest("[data-cat]");
    if (!b) return;
    cat = b.dataset.cat;
    apply();
  });

  [sizeSel, sortSel, inStock].forEach((el) => el.addEventListener("change", apply));
  search.addEventListener("input", apply);

  apply();
})();
