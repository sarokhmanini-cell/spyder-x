/* =========================================================
   SPIDBRICK — Local product manager
   IMPORTANT: this saves to the LocalStorage of THIS browser only.
   To publish changes for all visitors, export JSON and commit it
   as data/products.json in the GitHub repository.
   ========================================================= */
(function () {
  "use strict";
  const SB = window.SB;
  SBLayout.init("");

  const listEl = document.getElementById("list");
  const form = document.getElementById("editor");
  const statusEl = document.getElementById("status");
  const imgBox = document.getElementById("imgBox");

  let products = [];
  let currentId = null;
  let images = [];

  const $ = (id) => document.getElementById(id);

  function setStatus(html, warn) {
    statusEl.className = "status-box" + (warn ? " warn" : "");
    statusEl.innerHTML = html;
  }

  async function load() {
    try {
      products = await SB.getCatalog();
    } catch (e) {
      setStatus("تعذّر تحميل data/products.json. افتح الصفحة عبر GitHub Pages أو خادم محلي.", true);
      return;
    }
    const isLocal = Array.isArray(SB.readJSON(SB.KEY_CATALOG, null));
    setStatus(isLocal
      ? "<b>تعمل بنسخة محلية</b> من الكتالوج في هذا المتصفح (عدد المنتجات: " + products.length + ")."
      : "<b>تعرض الكتالوج الأصلي</b> (data/products.json). أي تعديل سيُحفظ محلياً أولاً.");
    renderList();
    if (products.length) select(products[0].id);
    else newProduct();
  }

  function persist() {
    const ok = SB.writeJSON(SB.KEY_CATALOG, products);
    if (!ok) {
      alert("مساحة التخزين المحلية ممتلئة. قلّل حجم الصور المرفوعة أو استخدم مسارات صور من المستودع، ثم صدّر الكتالوج.");
      return false;
    }
    renderList();
    setStatus("<b>تم الحفظ محلياً</b> في هذا المتصفح. لتظهر للزبائن صدّر JSON وارفعه إلى المستودع.");
    return true;
  }

  function renderList() {
    listEl.innerHTML = products.length
      ? products.map((p) => `
          <button type="button" data-id="${SB.esc(p.id)}" class="${p.id === currentId ? "on" : ""}">
            <b>${SB.esc(p.name)}</b><br>
            <small class="muted">${SB.money(SB.unitPrice(p))} · مخزون ${SB.stockTotal(p)}</small>
          </button>`).join("")
      : '<p class="muted" style="padding:10px">لا توجد منتجات.</p>';
  }

  function select(id) {
    const p = products.find((x) => x.id === id);
    if (!p) return;
    currentId = id;
    $("f_id").value = p.id;
    $("f_name").value = p.name || "";
    $("f_category").value = p.category || "tees";
    $("f_price").value = p.price || 0;
    $("f_sale").value = p.salePrice || 0;
    $("f_desc").value = p.description || "";
    $("f_details").value = (p.details || []).join("\n");
    $("f_colors").value = (p.colors || []).map((c) => c.name + "|" + c.hex).join("\n");
    $("f_date").value = p.createdAt || "";
    $("f_featured").checked = !!p.featured;
    $("f_best").checked = !!p.bestSeller;
    SB.SIZES.forEach((s) => { $("s_" + s).value = (p.stock && p.stock[s]) || 0; });
    images = (p.images || []).slice();
    $("f_imgUrl").value = "";
    renderImages();
    clearErrors();
    renderList();
  }

  function newProduct() {
    currentId = null;
    $("f_id").value = "(سيُنشأ عند الحفظ)";
    $("f_name").value = "";
    $("f_category").value = "tees";
    $("f_price").value = "";
    $("f_sale").value = 0;
    $("f_desc").value = "";
    $("f_details").value = "";
    $("f_colors").value = "";
    $("f_date").value = new Date().toISOString().slice(0, 10);
    $("f_featured").checked = false;
    $("f_best").checked = false;
    SB.SIZES.forEach((s) => { $("s_" + s).value = 0; });
    images = [];
    $("f_imgUrl").value = "";
    renderImages();
    clearErrors();
    renderList();
    $("f_name").focus();
  }

  function renderImages() {
    imgBox.innerHTML = images.length
      ? images.map((src, i) => `
          <div class="thumb-chip">
            <img src="${SB.esc(src)}" alt="">
            <button type="button" data-rm="${i}" aria-label="حذف الصورة">×</button>
          </div>`).join("")
      : '<p class="muted" style="font-size:14px">لا توجد صور بعد.</p>';
  }

  function clearErrors() {
    form.querySelectorAll("[data-err]").forEach((el) => { el.textContent = ""; });
    form.querySelectorAll(".invalid").forEach((el) => el.classList.remove("invalid"));
  }

  function showError(id, msg) {
    const err = form.querySelector(`[data-err="${id}"]`);
    if (err) err.textContent = msg;
    $(id).classList.add("invalid");
  }

  function parseColors(text) {
    return text.split("\n").map((l) => l.trim()).filter(Boolean).map((line) => {
      const parts = line.split("|").map((s) => s.trim());
      return { name: parts[0] || "", hex: parts[1] || "#777777" };
    }).filter((c) => c.name);
  }

  function readForm() {
    clearErrors();
    const name = $("f_name").value.trim();
    const price = Math.round(Number($("f_price").value));
    const sale = Math.round(Number($("f_sale").value) || 0);
    let ok = true;

    if (name.length < 2) { showError("f_name", "أدخل اسم المنتج"); ok = false; }
    if (!(price > 0)) { showError("f_price", "أدخل سعراً أكبر من صفر"); ok = false; }
    if (sale && sale >= price) { showError("f_sale", "سعر التخفيض يجب أن يكون أقل من السعر الأصلي"); ok = false; }
    if (!ok) return null;

    const stock = {};
    SB.SIZES.forEach((s) => { stock[s] = Math.max(0, Math.floor(Number($("s_" + s).value) || 0)); });

    const id = currentId || ("p-" + Date.now().toString(36));
    return {
      id,
      name,
      category: $("f_category").value,
      price,
      salePrice: sale > 0 ? sale : null,
      description: $("f_desc").value.trim(),
      details: $("f_details").value.split("\n").map((l) => l.trim()).filter(Boolean),
      colors: parseColors($("f_colors").value),
      images: images.slice(),
      stock,
      featured: $("f_featured").checked,
      bestSeller: $("f_best").checked,
      createdAt: $("f_date").value || new Date().toISOString().slice(0, 10)
    };
  }

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const p = readForm();
    if (!p) return;
    const idx = products.findIndex((x) => x.id === p.id);
    if (idx >= 0) products[idx] = p;
    else products.unshift(p);
    if (persist()) select(p.id);
  });

  $("deleteBtn").addEventListener("click", () => {
    if (!currentId) { newProduct(); return; }
    const p = products.find((x) => x.id === currentId);
    if (!p || !confirm("حذف المنتج «" + p.name + "» من هذا المتصفح؟")) return;
    products = products.filter((x) => x.id !== currentId);
    persist();
    if (products.length) select(products[0].id);
    else newProduct();
  });

  $("newBtn").addEventListener("click", newProduct);

  listEl.addEventListener("click", (e) => {
    const b = e.target.closest("[data-id]");
    if (b) select(b.dataset.id);
  });

  $("addUrlBtn").addEventListener("click", () => {
    const v = $("f_imgUrl").value.trim();
    if (!v) return;
    images.push(v);
    $("f_imgUrl").value = "";
    renderImages();
  });

  imgBox.addEventListener("click", (e) => {
    const b = e.target.closest("[data-rm]");
    if (!b) return;
    images.splice(Number(b.dataset.rm), 1);
    renderImages();
  });

  /* Resize uploaded images to keep LocalStorage small */
  function resizeImage(file, max) {
    return new Promise((resolve, reject) => {
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.onload = () => {
        const ratio = Math.min(1, max / Math.max(img.width, img.height));
        const c = document.createElement("canvas");
        c.width = Math.round(img.width * ratio);
        c.height = Math.round(img.height * ratio);
        c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
        URL.revokeObjectURL(url);
        resolve(c.toDataURL("image/jpeg", 0.82));
      };
      img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("bad image")); };
      img.src = url;
    });
  }

  $("f_upload").addEventListener("change", async (e) => {
    const file = e.target.files && e.target.files[0];
    e.target.value = "";
    if (!file) return;
    try {
      images.push(await resizeImage(file, 900));
      renderImages();
    } catch (err) {
      alert("تعذّر قراءة الصورة. جرّب صورة أخرى (JPG أو PNG).");
    }
  });

  $("exportBtn").addEventListener("click", () => {
    const blob = new Blob([JSON.stringify({ brand: "SPIDBRICK", products }, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "products.json";
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  });

  $("importFile").addEventListener("change", async (e) => {
    const file = e.target.files && e.target.files[0];
    e.target.value = "";
    if (!file) return;
    try {
      const json = JSON.parse(await file.text());
      if (!Array.isArray(json.products)) throw new Error("no products");
      const valid = json.products.every((p) => p && p.id && p.name && typeof p.price === "number");
      if (!valid) throw new Error("invalid");
      products = json.products;
      if (persist()) load();
    } catch (err) {
      alert("ملف غير صالح. يجب أن يحتوي على مصفوفة products فيها id و name و price.");
    }
  });

  $("resetBtn").addEventListener("click", () => {
    if (!confirm("إعادة الضبط تحذف التعديلات المحلية في هذا المتصفح وتعرض الكتالوج الأصلي. متابعة؟")) return;
    localStorage.removeItem(SB.KEY_CATALOG);
    location.reload();
  });

  load();
})();
