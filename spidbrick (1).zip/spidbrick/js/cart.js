/* Cart page: quantities, removal, totals */
(async function () {
  "use strict";
  const SB = window.SB;
  SBLayout.init("cart");

  const box = document.getElementById("cartBox");
  const summary = document.getElementById("summary");
  const sumCount = document.getElementById("sumCount");
  const sumSub = document.getElementById("sumSub");
  const sumTotal = document.getElementById("sumTotal");
  const sumNote = document.getElementById("sumNote");
  const checkoutBtn = document.getElementById("checkoutBtn");

  function lineHTML(l) {
    const img = SB.imageFor(l.product, l.item.color)[0];
    const notes = [];
    if (l.unavailable) notes.push('<div class="warn">هذا المقاس نفد. أزله من السلة أو غيّر المقاس.</div>');
    else if (l.item.qty > l.stock) notes.push('<div class="warn">المتوفر: ' + l.stock + ' قطع فقط</div>');
    return `
      <div class="line ${l.unavailable || l.item.qty > l.stock ? "bad" : ""}" data-i="${l.index}">
        <img src="${SB.esc(img)}" alt="${SB.esc(l.product.name)}">
        <div>
          <h3>${SB.esc(l.product.name)}</h3>
          <div class="meta">المقاس: <b>${SB.esc(l.item.size)}</b>${l.item.color ? " · اللون: " + SB.esc(l.item.color) : ""} · ${SB.money(l.price)}</div>
          ${notes.join("")}
          <div class="actions">
            <div class="qty">
              <button type="button" data-act="dec" aria-label="تقليل">−</button>
              <span>${l.item.qty}</span>
              <button type="button" data-act="inc" aria-label="زيادة">+</button>
            </div>
            <button type="button" class="btn small danger" data-act="rm">حذف</button>
          </div>
        </div>
        <div class="lt">${SB.money(l.lineTotal)}</div>
      </div>`;
  }

  async function render() {
    const d = await SB.cartDetails();

    if (!d.lines.length) {
      box.innerHTML = '<div class="empty"><p>سلتك فارغة حالياً.</p><a class="btn primary" href="shop.html">ابدأ التسوق</a></div>';
      summary.style.display = "none";
      return;
    }

    summary.style.display = "";
    box.innerHTML = d.lines.map(lineHTML).join("");
    sumCount.textContent = d.count;
    sumSub.textContent = SB.money(d.subtotal);
    sumTotal.textContent = SB.money(d.subtotal) + " + التوصيل";

    const problems = d.lines.filter((l) => l.unavailable || l.item.qty > l.stock).length;
    sumNote.innerHTML = problems
      ? '<span style="color:var(--danger)">' + problems + " منتج يحتاج تعديل الكمية أو الإزالة قبل إتمام الطلب.</span>"
      : (SB.C.freeDeliveryThreshold
        ? "التوصيل مجاني للطلبات التي تتجاوز " + SB.money(SB.C.freeDeliveryThreshold) + "."
        : "");
    checkoutBtn.disabled = problems > 0;
  }

  box.addEventListener("click", async (e) => {
    const btn = e.target.closest("[data-act]");
    if (!btn) return;
    const row = btn.closest("[data-i]");
    const index = Number(row.dataset.i);
    const act = btn.dataset.act;

    if (act === "rm") {
      SB.removeFromCart(index);
      SB.toast("تمت إزالة المنتج");
    } else {
      const item = SB.getCart()[index];
      if (!item) return;
      const next = act === "inc" ? item.qty + 1 : item.qty - 1;
      const res = await SB.setCartQty(index, next);
      if (res.clamped) SB.toast("وصلت إلى الحد المتوفر لهذا المقاس");
    }
    render();
  });

  checkoutBtn.addEventListener("click", () => {
    window.location.href = "checkout.html";
  });

  render();
})();
