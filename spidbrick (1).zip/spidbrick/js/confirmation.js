/* Order confirmation: shows the last order saved on THIS device and offers a WhatsApp resend. */
(function () {
  "use strict";
  const SB = window.SB;
  SBLayout.init("cart");

  const box = document.getElementById("confirmBox");
  const order = SB.readJSON(SB.KEY_LAST_ORDER, null);
  const wantedId = SB.getParam("id");

  if (!order || (wantedId && order.id !== wantedId)) {
    box.innerHTML = `
      <div class="panel center">
        <h2>لا يوجد طلب حديث على هذا الجهاز</h2>
        <p class="muted">إذا أرسلت طلبك عبر واتساب فسيتواصل معك فريق المتجر لتأكيده.</p>
        <a class="btn primary" href="shop.html">العودة إلى المتجر</a>
      </div>`;
    return;
  }

  const waReady = SB.whatsappReady();
  const resend = waReady
    ? `<a class="btn" href="${SB.whatsappUrl(SB.buildOrderMessage(order))}" target="_blank" rel="noopener">أعد إرسال الطلب على واتساب</a>`
    : '<p class="notice warn">رقم واتساب للمتجر غير مضبوط بعد.</p>';

  const lines = order.lines.map((l) => `
      <div class="mini-line">
        <span>${SB.esc(l.name)} × ${l.qty}<br><small class="muted">المقاس ${SB.esc(l.size)}${l.color ? " · " + SB.esc(l.color) : ""}</small></span>
        <span>${SB.money(l.total)}</span>
      </div>`).join("");

  box.innerHTML = `
    <div class="panel">
      <h2 style="text-align:center">شكراً لطلبك</h2>
      <p class="center muted">رقم الطلب: <b style="color:var(--white)">${SB.esc(order.id)}</b></p>
      <div class="notice">
        تم تجهيز رسالة الطلب لإرسالها إلى المتجر عبر واتساب. الطلب لا يُحفظ في قاعدة بيانات على الموقع؛
        إذا لم تصل الرسالة إلى واتساب فاضغط زر إعادة الإرسال أدناه. الدفع عند الاستلام.
      </div>

      <h3>تفاصيل الطلب</h3>
      <p class="muted" style="margin-top:0">${SB.esc(order.customer.name)} · ${SB.esc(SB.wilayaLabel(order.customer.wilaya))} · ${SB.esc(order.customer.city)}</p>
      ${lines}
      <div class="mini-line"><span>المجموع الفرعي</span><span>${SB.money(order.subtotal)}</span></div>
      <div class="mini-line"><span>التوصيل</span><span>${order.fee === 0 ? "مجاني" : SB.money(order.fee)}</span></div>
      <div class="mini-line" style="font-weight:800;color:var(--white);border:0;font-size:18px"><span>الإجمالي</span><span>${SB.money(order.total)}</span></div>

      <div class="cta" style="margin-top:22px">
        ${resend}
        <a class="btn primary" href="shop.html">متابعة التسوق</a>
      </div>
    </div>`;

  /* The order has been handed off to WhatsApp, so the cart can be emptied. */
  if (!wantedId || wantedId === order.id) SB.clearCart();
})();
