/* Homepage: featured, new arrivals, best sellers */
(async function () {
  "use strict";
  const SB = window.SB;
  const C = window.SB_CONFIG;
  SBLayout.init("home");

  const promo = document.getElementById("promoText");
  if (promo) {
    promo.textContent = C.freeDeliveryThreshold
      ? "التوصيل مجاني للطلبات التي تتجاوز " + SB.money(C.freeDeliveryThreshold) + "."
      : "عروض حصرية على القطع المختارة.";
  }

  const waBtn = document.getElementById("waBtn");
  if (waBtn && SB.whatsappReady()) waBtn.href = "https://wa.me/" + C.whatsappNumber;

  const targets = {
    featured: document.getElementById("featured"),
    newArrivals: document.getElementById("newArrivals"),
    best: document.getElementById("best")
  };

  function fill(el, list, emptyMsg) {
    if (!el) return;
    el.innerHTML = list.length
      ? list.map((p) => SB.cardHTML(p)).join("")
      : '<div class="empty">' + emptyMsg + "</div>";
  }

  try {
    const all = await SB.getCatalog();
    const newest = all.slice().sort((a, b) => String(b.createdAt || "").localeCompare(String(a.createdAt || "")));
    fill(targets.featured, all.filter((p) => p.featured).slice(0, 4), "قريباً منتجات مميزة.");
    fill(targets.newArrivals, newest.slice(0, 4), "قريباً وصول جديد.");
    fill(targets.best, all.filter((p) => p.bestSeller).slice(0, 4), "قريباً الأكثر مبيعاً.");
  } catch (e) {
    Object.values(targets).forEach((el) => {
      if (el) el.innerHTML = '<div class="empty">تعذّر تحميل المنتجات. افتح الموقع عبر GitHub Pages أو عبر خادم محلي (انظر README).</div>';
    });
  }
})();
