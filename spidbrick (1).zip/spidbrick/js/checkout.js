/* Checkout: validation, delivery fee, WhatsApp order (no server, no database) */
(async function () {
  "use strict";
  const SB = window.SB;
  const C = window.SB_CONFIG;
  SBLayout.init("cart");

  const form = document.getElementById("checkoutForm");
  const wilayaSel = document.getElementById("wilaya");
  const wrap = document.getElementById("checkoutWrap");
  const msgBox = document.getElementById("checkoutMsg");
  const submitBtn = document.getElementById("submitBtn");
  const sumLines = document.getElementById("sumLines");
  const sumSub = document.getElementById("sumSub");
  const sumFee = document.getElementById("sumFee");
  const sumTotal = document.getElementById("sumTotal");

  /* Populate the 58 wilayas */
  wilayaSel.innerHTML = '<option value="">اختر الولاية</option>' +
    C.wilayas.map(([code, name]) => `<option value="${code}">${code} - ${name}</option>`).join("");

  if (!SB.whatsappReady()) {
    msgBox.innerHTML = '<div class="notice warn">لم يتم ضبط رقم واتساب للمتجر بعد. عدّل whatsappNumber في js/config.js قبل النشر، وإلا لن يتم إرسال الطلبات.</div>';
    submitBtn.disabled = true;
  }

  const fields = {
    name: document.getElementById("name"),
    phone: document.getElementById("phone"),
    wilaya: wilayaSel,
    city: document.getElementById("city"),
    address: document.getElementById("address"),
    notes: document.getElementById("notes")
  };

  function readValues() {
    return {
      name: fields.name.value.trim(),
      phone: SB.normalizePhone(fields.phone.value),
      wilaya: fields.wilaya.value,
      city: fields.city.value.trim(),
      address: fields.address.value.trim(),
      notes: fields.notes.value.trim()
    };
  }

  function validate(v) {
    const e = {};
    if (v.name.length < 3 || v.name.length > 60) e.name = "الاسم يجب أن يكون بين 3 و60 حرفاً";
    if (!SB.isPhoneValid(v.phone)) e.phone = "أدخل رقم هاتف جزائري صحيح (مثال: 0555123456)";
    if (!v.wilaya) e.wilaya = "اختر الولاية";
    if (v.city.length < 2 || v.city.length > 60) e.city = "أدخل اسم البلدية أو المدينة";
    if (v.address.length < 5 || v.address.length > 200) e.address = "أدخل العنوان الكامل (5 أحرف على الأقل)";
    if (v.notes.length > 300) e.notes = "الملاحظات طويلة جداً (300 حرف كحد أقصى)";
    return e;
  }

  function showErrors(errors) {
    Object.keys(fields).forEach((k) => {
      const input = fields[k];
      const err = document.querySelector(`[data-err="${k}"]`);
      const msg = errors[k] || "";
      if (err) err.textContent = msg;
      input.classList.toggle("invalid", !!msg);
    });
  }

  async function renderSummary() {
    const d = await SB.cartDetails();
    if (!d.lines.length) {
      wrap.style.display = "none";
      msgBox.innerHTML = '<div class="empty"><p>سلتك فارغة. أضف منتجات قبل إتمام الطلب.</p><a class="btn primary" href="shop.html">المتجر</a></div>';
      return null;
    }
    sumLines.innerHTML = d.lines.map((l) =>
      `<div class="mini-line"><span>${SB.esc(l.product.name)} × ${l.item.qty}<br><small class="muted">المقاس ${SB.esc(l.item.size)}${l.item.color ? " · " + SB.esc(l.item.color) : ""}</small></span><span>${SB.money(l.lineTotal)}</span></div>`
    ).join("");

    const fee = SB.deliveryFee(fields.wilaya.value, d.subtotal);
    sumSub.textContent = SB.money(d.subtotal);
    sumFee.textContent = fee === null ? "اختر الولاية" : (fee === 0 ? "مجاني" : SB.money(fee));
    sumTotal.textContent = fee === null ? SB.money(d.subtotal) + " + التوصيل" : SB.money(d.subtotal + fee);
    return { d, fee };
  }

  fields.wilaya.addEventListener("change", renderSummary);

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    if (!SB.whatsappReady()) return;

    const values = readValues();
    fields.phone.value = values.phone;
    const errors = validate(values);
    showErrors(errors);
    if (Object.keys(errors).length) {
      const first = Object.keys(errors)[0];
      fields[first].focus();
      return;
    }

    const cart = await SB.cartDetails();
    if (!cart.lines.length) { await renderSummary(); return; }

    const problems = cart.lines.filter((l) => l.unavailable || l.item.qty > l.stock);
    if (problems.length) {
      SB.toast("بعض المنتجات تغيّر توفرها. راجع السلة.");
      window.location.href = "cart.html";
      return;
    }

    const fee = SB.deliveryFee(values.wilaya, cart.subtotal);
    const order = {
      id: SB.newOrderId(),
      createdAt: new Date().toISOString(),
      customer: values,
      lines: cart.lines.map((l) => ({
        ref: l.product.id,
        name: l.product.name,
        size: l.item.size,
        color: l.item.color,
        qty: l.item.qty,
        unit: l.price,
        total: l.lineTotal
      })),
      subtotal: cart.subtotal,
      fee: fee === null ? 0 : fee,
      total: cart.subtotal + (fee === null ? 0 : fee)
    };

    SB.writeJSON(SB.KEY_LAST_ORDER, order);
    const url = SB.whatsappUrl(SB.buildOrderMessage(order));

    /* Open WhatsApp in a new tab; the confirmation page keeps a backup button. */
    window.open(url, "_blank");
    window.location.href = "order-confirmation.html?id=" + encodeURIComponent(order.id);
  });

  await renderSummary();
})();
