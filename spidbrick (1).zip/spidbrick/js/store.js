/* =========================================================
   SPIDBRICK — Shared store logic
   Catalog loading, cart (LocalStorage), delivery fees,
   WhatsApp order message and small helpers.
   ========================================================= */
(function () {
  "use strict";

  const C = window.SB_CONFIG;
  const KEY_CART = "spidbrick_cart_v1";
  const KEY_CATALOG = "spidbrick_catalog_override_v1";
  const KEY_LAST_ORDER = "spidbrick_last_order_v1";
  const SIZES = ["S", "M", "L", "XL", "XXL"];
  const CATEGORIES = { tees: "تيشيرتات", hoodies: "هوديات", pants: "سراويل", jackets: "جاكيتات" };
  const MAX_QTY = 20;

  /* ---------- Generic helpers ---------- */
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[c]));

  const money = (n) => Math.round(Number(n) || 0).toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ") + " " + C.currency;

  const readJSON = (key, fallback) => {
    try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) : fallback; }
    catch (e) { return fallback; }
  };

  const writeJSON = (key, value) => {
    try { localStorage.setItem(key, JSON.stringify(value)); return true; }
    catch (e) { return false; }
  };

  const getParam = (name) => new URL(window.location.href).searchParams.get(name);

  function toast(msg) {
    let el = document.getElementById("sb-toast");
    if (!el) {
      el = document.createElement("div");
      el.id = "sb-toast";
      el.className = "toast";
      el.setAttribute("role", "status");
      document.body.appendChild(el);
    }
    el.textContent = msg;
    el.classList.add("show");
    clearTimeout(el._t);
    el._t = setTimeout(() => el.classList.remove("show"), 2600);
  }

  /* ---------- Catalog ---------- */
  let baseCatalog = null;

  async function fetchBase() {
    if (baseCatalog) return baseCatalog;
    const res = await fetch("data/products.json", { cache: "no-cache" });
    if (!res.ok) throw new Error("Cannot load data/products.json");
    const json = await res.json();
    baseCatalog = Array.isArray(json.products) ? json.products : [];
    return baseCatalog;
  }

  /* Local override (set from admin.html in THIS browser only). */
  async function getCatalog() {
    const override = readJSON(KEY_CATALOG, null);
    if (Array.isArray(override)) return JSON.parse(JSON.stringify(override));
    return JSON.parse(JSON.stringify(await fetchBase()));
  }

  const unitPrice = (p) => (p.salePrice && p.salePrice > 0 && p.salePrice < p.price) ? p.salePrice : p.price;
  const onSale = (p) => unitPrice(p) < p.price;
  const stockFor = (p, size) => Number(p.stock && p.stock[size]) || 0;
  const stockTotal = (p) => SIZES.reduce((t, s) => t + stockFor(p, s), 0);

  /* Images for a product, optionally per color (colorImages is optional). */
  function imageFor(p, color) {
    const perColor = color && p.colorImages && p.colorImages[color];
    const list = (perColor && perColor.length) ? perColor : (p.images || []);
    return list.length ? list : ["assets/products/placeholder.svg"];
  }

  /* ---------- Cart (LocalStorage) ---------- */
  function getCart() {
    const cart = readJSON(KEY_CART, []);
    return Array.isArray(cart)
      ? cart.filter((i) => i && i.id && i.size && Number(i.qty) > 0)
      : [];
  }

  function saveCart(cart) {
    writeJSON(KEY_CART, cart);
    updateCartBadge();
    window.dispatchEvent(new Event("sb-cart-changed"));
  }

  function cartCount() {
    return getCart().reduce((t, i) => t + Number(i.qty), 0);
  }

  async function cartDetails() {
    const catalog = await getCatalog();
    const lines = [];
    getCart().forEach((item, index) => {
      const p = catalog.find((x) => x.id === item.id);
      if (!p) return;
      const stock = stockFor(p, item.size);
      const price = unitPrice(p);
      lines.push({
        index, item, product: p, price, stock,
        lineTotal: price * item.qty,
        unavailable: stock <= 0
      });
    });
    return {
      lines,
      subtotal: lines.reduce((t, l) => t + l.lineTotal, 0),
      count: lines.reduce((t, l) => t + l.item.qty, 0)
    };
  }

  async function addToCart(id, size, color, qty) {
    const catalog = await getCatalog();
    const p = catalog.find((x) => x.id === id);
    if (!p) return { ok: false, msg: "هذا المنتج غير متوفر" };
    if (!size) return { ok: false, msg: "اختر المقاس أولاً" };
    const stock = stockFor(p, size);
    if (stock <= 0) return { ok: false, msg: "هذا المقاس نفد حالياً" };

    const cart = getCart();
    const colorVal = color || "";
    const existing = cart.find((i) => i.id === id && i.size === size && i.color === colorVal);
    const current = existing ? existing.qty : 0;
    const want = Math.min(Math.max(1, Math.floor(Number(qty) || 1)), MAX_QTY);

    if (current + want > stock) {
      return { ok: false, msg: "الكمية المتاحة لهذا المقاس: " + stock };
    }
    if (existing) existing.qty += want;
    else cart.push({ id, size, color: colorVal, qty: want });
    saveCart(cart);
    return { ok: true, msg: "تمت الإضافة إلى السلة" };
  }

  async function setCartQty(index, qty) {
    const cart = getCart();
    const item = cart[index];
    if (!item) return { ok: false, qty: 0, clamped: false };
    const catalog = await getCatalog();
    const p = catalog.find((x) => x.id === item.id);
    const stock = p ? stockFor(p, item.size) : 0;
    let q = Math.min(Math.max(1, Math.floor(Number(qty) || 1)), MAX_QTY);
    let clamped = false;
    if (stock > 0 && q > stock) { q = stock; clamped = true; }
    item.qty = q;
    saveCart(cart);
    return { ok: true, qty: q, clamped };
  }

  function removeFromCart(index) {
    const cart = getCart();
    cart.splice(index, 1);
    saveCart(cart);
  }

  function clearCart() {
    saveCart([]);
  }

  function updateCartBadge() {
    const n = cartCount();
    document.querySelectorAll("[data-cart-count]").forEach((el) => { el.textContent = n; });
  }

  /* ---------- Delivery ---------- */
  /* Returns a number (DZD), or null when the wilaya is not chosen yet. */
  function deliveryFee(wilayaCode, subtotal) {
    if (C.freeDeliveryThreshold && subtotal >= C.freeDeliveryThreshold) return 0;
    if (!wilayaCode) return null;
    return Object.prototype.hasOwnProperty.call(C.deliveryFees, wilayaCode)
      ? C.deliveryFees[wilayaCode]
      : C.defaultDeliveryFee;
  }

  function wilayaLabel(code) {
    const w = C.wilayas.find((x) => x[0] === code);
    return w ? (w[0] + " - " + w[1]) : code;
  }

  /* ---------- Validation ---------- */
  const normalizePhone = (v) => String(v || "").replace(/[\s.\-]/g, "");
  const isPhoneValid = (v) => /^0[567]\d{8}$/.test(normalizePhone(v));

  /* WhatsApp is ready only when the placeholder number has been replaced. */
  function whatsappReady() {
    const n = String(C.whatsappNumber || "");
    return /^\d{11,15}$/.test(n) && !n.startsWith("213000");
  }

  function whatsappUrl(text) {
    return "https://wa.me/" + C.whatsappNumber + "?text=" + encodeURIComponent(text);
  }

  /* ---------- Orders (no server: the order goes to WhatsApp) ---------- */
  function newOrderId() {
    const d = new Date();
    const ymd = String(d.getFullYear()).slice(2)
      + String(d.getMonth() + 1).padStart(2, "0")
      + String(d.getDate()).padStart(2, "0");
    const rnd = Math.random().toString(36).slice(2, 6).toUpperCase().padEnd(4, "X");
    return "SB-" + ymd + "-" + rnd;
  }

  function buildOrderMessage(o) {
    const L = [];
    L.push("🕷️ *طلب جديد — SPIDBRICK*");
    L.push("رقم الطلب: " + o.id);
    L.push("━━━━━━━━━━━━");
    L.push("👤 الاسم: " + o.customer.name);
    L.push("📞 الهاتف: " + o.customer.phone);
    L.push("📍 الولاية: " + wilayaLabel(o.customer.wilaya));
    L.push("🏙️ البلدية/المدينة: " + o.customer.city);
    L.push("🏠 العنوان: " + o.customer.address);
    if (o.customer.notes) L.push("📝 ملاحظات: " + o.customer.notes);
    L.push("━━━━━━━━━━━━");
    o.lines.forEach((l, i) => {
      L.push((i + 1) + ") " + l.name);
      L.push("   المقاس: " + l.size + (l.color ? " | اللون: " + l.color : "") + " | الكمية: " + l.qty);
      L.push("   السعر: " + money(l.total));
    });
    L.push("━━━━━━━━━━━━");
    L.push("المجموع الفرعي: " + money(o.subtotal));
    L.push("التوصيل: " + (o.fee === 0 ? "مجاني" : money(o.fee)));
    L.push("*الإجمالي: " + money(o.total) + "*");
    L.push("💵 طريقة الدفع: الدفع عند الاستلام");
    return L.join("\n");
  }

  /* ---------- UI helpers ---------- */
  function cardHTML(p) {
    const imgs = imageFor(p, "");
    const img = imgs[0];
    const img2 = imgs[1] || imgs[0];
    const sale = onSale(p);
    const soldOut = stockTotal(p) <= 0;
    return `<a class="card" href="product.html?id=${encodeURIComponent(p.id)}">
      <div class="card-media">
        <img src="${esc(img)}" alt="${esc(p.name)}" loading="lazy">
        <img class="alt" src="${esc(img2)}" alt="" loading="lazy" aria-hidden="true">
        ${sale ? '<span class="badge">تخفيض</span>' : ""}
        ${soldOut ? '<span class="badge out">نفد</span>' : ""}
      </div>
      <div class="card-body">
        <h3>${esc(p.name)}</h3>
        <p class="price">${sale
          ? "<s>" + money(p.price) + "</s> <b>" + money(unitPrice(p)) + "</b>"
          : "<b>" + money(p.price) + "</b>"}</p>
      </div>
    </a>`;
  }

  window.SB = {
    C, KEY_CATALOG, KEY_LAST_ORDER, SIZES, CATEGORIES, MAX_QTY,
    esc, money, readJSON, writeJSON, getParam, toast,
    fetchBase, getCatalog, unitPrice, onSale, stockFor, stockTotal, imageFor,
    getCart, saveCart, cartCount, cartDetails, addToCart, setCartQty, removeFromCart, clearCart,
    updateCartBadge, deliveryFee, wilayaLabel,
    normalizePhone, isPhoneValid, whatsappReady, whatsappUrl,
    newOrderId, buildOrderMessage, cardHTML
  };

  window.addEventListener("sb-cart-changed", updateCartBadge);
  window.addEventListener("storage", updateCartBadge);
})();
