/* =========================================================
   SPIDBRICK — STORE CONFIGURATION
   Edit this file to set your real contact details and rules.
   ========================================================= */
window.SB_CONFIG = {
  brand: "SPIDBRICK",
  slogan: "WEAR THE DARKNESS",
  currency: "دج",

  /* WhatsApp number in international format, digits only, no "+" and no spaces.
     Algeria example: 213 + 9 digits WITHOUT the leading 0  →  213555123456
     Until you replace the placeholder, WhatsApp orders are blocked on purpose. */
  whatsappNumber: "213000000000",

  instagram: "https://www.instagram.com/spidbrick",
  tiktok: "https://www.tiktok.com/@spidbrick",

  /* Delivery fees in DZD. Keys are wilaya codes. Values below are examples: set your real prices. */
  defaultDeliveryFee: 600,
  deliveryFees: {
    "01": 1000, "11": 1200, "33": 1200, "37": 1200, "49": 1200,
    "50": 1200, "53": 1200, "54": 1200, "56": 1200
  },

  /* Orders with a subtotal at or above this amount get free delivery. Use null to disable. */
  freeDeliveryThreshold: 15000,

  /* All 58 wilayas of Algeria: [code, Arabic name] */
  wilayas: [
    ["01", "أدرار"], ["02", "الشلف"], ["03", "الأغواط"], ["04", "أم البواقي"],
    ["05", "باتنة"], ["06", "بجاية"], ["07", "بسكرة"], ["08", "بشار"],
    ["09", "البليدة"], ["10", "البويرة"], ["11", "تمنراست"], ["12", "تبسة"],
    ["13", "تلمسان"], ["14", "تيارت"], ["15", "تيزي وزو"], ["16", "الجزائر"],
    ["17", "الجلفة"], ["18", "جيجل"], ["19", "سطيف"], ["20", "سعيدة"],
    ["21", "سكيكدة"], ["22", "سيدي بلعباس"], ["23", "عنابة"], ["24", "قالمة"],
    ["25", "قسنطينة"], ["26", "المدية"], ["27", "مستغانم"], ["28", "المسيلة"],
    ["29", "معسكر"], ["30", "ورقلة"], ["31", "وهران"], ["32", "البيض"],
    ["33", "إليزي"], ["34", "برج بوعريريج"], ["35", "بومرداس"], ["36", "الطارف"],
    ["37", "تندوف"], ["38", "تيسمسيلت"], ["39", "الوادي"], ["40", "خنشلة"],
    ["41", "سوق أهراس"], ["42", "تيبازة"], ["43", "ميلة"], ["44", "عين الدفلى"],
    ["45", "النعامة"], ["46", "عين تموشنت"], ["47", "غرداية"], ["48", "غليزان"],
    ["49", "تيميمون"], ["50", "برج باجي مختار"], ["51", "أولاد جلال"], ["52", "بني عباس"],
    ["53", "عين صالح"], ["54", "عين قزام"], ["55", "تقرت"], ["56", "جانت"],
    ["57", "المغير"], ["58", "المنيعة"]
  ]
};
