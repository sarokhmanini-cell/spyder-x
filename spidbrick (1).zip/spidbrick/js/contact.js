/* Contact page: WhatsApp links and a message composer (no backend). */
(function () {
  "use strict";
  const SB = window.SB;
  const C = window.SB_CONFIG;
  SBLayout.init("contact");

  const waLink = document.getElementById("waLink");
  const notice = document.getElementById("contactMsg");
  const sendBtn = document.getElementById("sendBtn");
  const form = document.getElementById("contactForm");

  const ready = SB.whatsappReady();
  if (ready) {
    waLink.href = "https://wa.me/" + C.whatsappNumber;
  } else {
    waLink.removeAttribute("target");
    waLink.href = "#";
    waLink.addEventListener("click", (e) => { e.preventDefault(); });
    waLink.textContent = "الرقم غير مضبوط بعد";
    waLink.classList.remove("primary");
    waLink.disabled = true;
    notice.innerHTML = '<div class="notice warn">رقم واتساب للمتجر لم يُضبط بعد. عدّل whatsappNumber في js/config.js.</div>';
    sendBtn.disabled = true;
  }

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    if (!ready) return;

    const name = document.getElementById("cName").value.trim();
    const text = document.getElementById("cText").value.trim();
    const errName = document.querySelector('[data-err="cName"]');
    const errText = document.querySelector('[data-err="cText"]');
    errName.textContent = name.length < 2 ? "أدخل اسمك" : "";
    errText.textContent = text.length < 3 ? "اكتب رسالة قصيرة" : "";
    if (name.length < 2 || text.length < 3) return;

    const message = "مرحباً SPIDBRICK، أنا " + name + ".\n" + text;
    window.open(SB.whatsappUrl(message), "_blank");
  });
})();
