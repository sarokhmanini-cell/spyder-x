/* =========================================================
   SPIDBRICK — Shared header & footer (injected into pages)
   ========================================================= */
(function () {
  "use strict";
  const C = window.SB_CONFIG;

  const NAV = [
    ["index.html", "الرئيسية", "home"],
    ["shop.html", "المتجر", "shop"],
    ["about.html", "عن العلامة", "about"],
    ["size-guide.html", "دليل المقاسات", "size"],
    ["faq.html", "الأسئلة الشائعة", "faq"],
    ["contact.html", "تواصل معنا", "contact"]
  ];

  function headerHTML(active) {
    const links = NAV.map(([href, label, key]) =>
      `<a href="${href}" class="${active === key ? "active" : ""}">${label}</a>`).join("");
    return `<header class="site-header">
      <div class="wrap bar">
        <a class="logo logo-link" href="index.html" aria-label="SPIDBRICK">SPIDBRICK</a>
        <nav class="nav" id="nav">${links}</nav>
        <div class="bar-actions">
          <a class="cart-link" href="cart.html" aria-label="السلة">السلة <span class="count" data-cart-count>0</span></a>
          <button class="menu-btn" id="menuBtn" type="button" aria-label="القائمة" aria-expanded="false" aria-controls="nav">☰</button>
        </div>
      </div>
    </header>`;
  }

  function footerHTML() {
    return `<footer class="site-footer">
      <div class="wrap foot-grid">
        <div>
          <div class="logo big">SPIDBRICK</div>
          <p class="slogan">${C.slogan}</p>
          <p class="muted">ملابس ستريتوير جزائرية بتصميم أسود وبنفسجي. الدفع عند الاستلام.</p>
        </div>
        <div>
          <h4>المتجر</h4>
          <a href="shop.html">كل المنتجات</a>
          <a href="cart.html">السلة</a>
          <a href="checkout.html">إتمام الطلب</a>
        </div>
        <div>
          <h4>المساعدة</h4>
          <a href="size-guide.html">دليل المقاسات</a>
          <a href="faq.html">الأسئلة الشائعة</a>
          <a href="contact.html">تواصل معنا</a>
          <a href="admin.html">إدارة المنتجات (محلية)</a>
        </div>
        <div>
          <h4>تابعنا</h4>
          <a href="${C.instagram}" target="_blank" rel="noopener">Instagram</a>
          <a href="${C.tiktok}" target="_blank" rel="noopener">TikTok</a>
          <a href="https://wa.me/${C.whatsappNumber}" target="_blank" rel="noopener">واتساب</a>
        </div>
      </div>
      <div class="wrap copy">© ${new Date().getFullYear()} SPIDBRICK — ${C.slogan}</div>
    </footer>`;
  }

  function init(activeKey) {
    const h = document.getElementById("site-header");
    if (h) h.outerHTML = headerHTML(activeKey || "");
    const f = document.getElementById("site-footer");
    if (f) f.outerHTML = footerHTML();

    const btn = document.getElementById("menuBtn");
    const nav = document.getElementById("nav");
    if (btn && nav) {
      btn.addEventListener("click", () => {
        const open = nav.classList.toggle("open");
        btn.setAttribute("aria-expanded", String(open));
      });
    }
    if (window.SB) window.SB.updateCartBadge();
  }

  window.SBLayout = { init };
})();
