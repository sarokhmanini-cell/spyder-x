/* Product details page: gallery, colors, sizes, stock, add to cart */
(async function () {
  "use strict";
  const SB = window.SB;
  SBLayout.init("shop");

  const root = document.getElementById("product");
  const relatedBox = document.getElementById("related");
  const id = SB.getParam("id");

  let catalog = [];
  try {
    catalog = await SB.getCatalog();
  } catch (e) {
    root.innerHTML = '<div class="empty">تعذّر تحميل المنتج. افتح الموقع عبر GitHub Pages أو خادم محلي.</div>';
    return;
  }

  const p = catalog.find((x) => x.id === id);
  if (!p) {
    root.innerHTML = '<div class="empty"><p>المنتج غير موجود أو تم حذفه.</p><a class="btn primary" href="shop.html">العودة إلى المتجر</a></div>';
    relatedBox.parentElement.style.display = "none";
    return;
  }

  document.title = p.name + " | SPIDBRICK";

  const st = {
    color: p.colors && p.colors.length ? p.colors[0].name : "",
    size: SB.SIZES.find((s) => SB.stockFor(p, s) > 0) || "",
    qty: 1,
    thumb: 0
  };

  const sale = SB.onSale(p);
  root.innerHTML = `
    <div class="gallery">
      <div class="main"><img id="mainImg" alt="${SB.esc(p.name)}"></div>
      <div class="thumbs" id="thumbs"></div>
    </div>
    <div class="buy">
      <p class="muted">${SB.esc(SB.CATEGORIES[p.category] || "")}</p>
      <h1>${SB.esc(p.name)}</h1>
      <p class="price">${sale
        ? '<s class="muted">' + SB.money(p.price) + '</s> <b>' + SB.money(SB.unitPrice(p)) + '</b>'
        : '<b>' + SB.money(p.price) + '</b>'}</p>
      <p class="desc">${SB.esc(p.description || "")}</p>

      <div id="colorBox"></div>
      <div id="sizeBox"></div>
      <div id="stockLine" class="stock-line" aria-live="polite"></div>

      <div class="buy-row">
        <div class="qty">
          <button type="button" id="minus" aria-label="تقليل">−</button>
          <input id="qty" type="number" min="1" value="1" inputmode="numeric" aria-label="الكمية">
          <button type="button" id="plus" aria-label="زيادة">+</button>
        </div>
        <button type="button" class="btn primary" id="addBtn" style="flex:1">أضف إلى السلة</button>
      </div>

      <ul class="details">${(p.details || []).map((d) => "<li>" + SB.esc(d) + "</li>").join("")}</ul>
    </div>`;

  const mainImg = document.getElementById("mainImg");
  const thumbsBox = document.getElementById("thumbs");
  const colorBox = document.getElementById("colorBox");
  const sizeBox = document.getElementById("sizeBox");
  const stockLine = document.getElementById("stockLine");
  const qtyInput = document.getElementById("qty");
  const addBtn = document.getElementById("addBtn");

  function renderGallery() {
    const imgs = SB.imageFor(p, st.color);
    if (st.thumb >= imgs.length) st.thumb = 0;
    mainImg.src = imgs[st.thumb];
    thumbsBox.innerHTML = imgs.length > 1
      ? imgs.map((src, i) => `<button type="button" class="${i === st.thumb ? "on" : ""}" data-thumb="${i}" aria-label="صورة ${i + 1}"><img src="${SB.esc(src)}" alt=""></button>`).join("")
      : "";
  }

  function renderColors() {
    if (!p.colors || !p.colors.length) { colorBox.innerHTML = ""; return; }
    colorBox.innerHTML = `
      <div class="opt-title"><span>اللون</span><span id="colorName">${SB.esc(st.color)}</span></div>
      <div class="swatches">
        ${p.colors.map((c) => `<button type="button" class="swatch ${c.name === st.color ? "on" : ""}" style="background:${SB.esc(c.hex)}" data-color="${SB.esc(c.name)}" aria-label="${SB.esc(c.name)}" title="${SB.esc(c.name)}"></button>`).join("")}
      </div>`;
  }

  function renderSizes() {
    sizeBox.innerHTML = `
      <div class="opt-title"><span>المقاس</span><a href="size-guide.html">دليل المقاسات</a></div>
      <div class="sizes">
        ${SB.SIZES.map((s) => {
          const stock = SB.stockFor(p, s);
          return `<button type="button" class="size-btn ${s === st.size ? "on" : ""}" data-size="${s}" ${stock <= 0 ? "disabled" : ""}>${s}</button>`;
        }).join("")}
      </div>`;
  }

  function renderStock() {
    const stock = st.size ? SB.stockFor(p, st.size) : 0;
    if (!st.size) {
      stockLine.className = "stock-line bad";
      stockLine.textContent = "اختر مقاساً لعرض التوفر";
    } else if (stock <= 0) {
      stockLine.className = "stock-line bad";
      stockLine.textContent = "هذا المقاس نفد حالياً";
    } else if (stock <= 3) {
      stockLine.className = "stock-line ok";
      stockLine.textContent = "متبقي " + stock + " قطع فقط";
    } else {
      stockLine.className = "stock-line ok";
      stockLine.textContent = "متوفر في المخزون";
    }

    qtyInput.max = Math.max(1, stock);
    if (stock > 0 && st.qty > stock) st.qty = stock;
    if (st.qty < 1) st.qty = 1;
    qtyInput.value = st.qty;
    addBtn.disabled = !st.size || stock <= 0;
  }

  function renderAll() {
    renderGallery();
    renderColors();
    renderSizes();
    renderStock();
  }

  renderAll();

  root.addEventListener("click", async (e) => {
    const thumb = e.target.closest("[data-thumb]");
    if (thumb) {
      st.thumb = Number(thumb.dataset.thumb);
      renderGallery();
      return;
    }
    const color = e.target.closest("[data-color]");
    if (color) {
      st.color = color.dataset.color;
      st.thumb = 0;
      renderGallery();
      renderColors();
      return;
    }
    const size = e.target.closest("[data-size]");
    if (size && !size.disabled) {
      st.size = size.dataset.size;
      st.qty = 1;
      renderSizes();
      renderStock();
      return;
    }
    if (e.target.closest("#minus")) { st.qty = Math.max(1, st.qty - 1); renderStock(); return; }
    if (e.target.closest("#plus")) {
      const max = st.size ? SB.stockFor(p, st.size) : 1;
      st.qty = Math.min(max, SB.MAX_QTY, st.qty + 1);
      renderStock();
      return;
    }
    if (e.target.closest("#addBtn")) {
      const res = await SB.addToCart(p.id, st.size, st.color, st.qty);
      SB.toast(res.msg);
    }
  });

  qtyInput.addEventListener("change", () => {
    const max = st.size ? SB.stockFor(p, st.size) : 1;
    st.qty = Math.min(Math.max(1, Math.floor(Number(qtyInput.value) || 1)), Math.max(1, max), SB.MAX_QTY);
    renderStock();
  });

  const related = catalog
    .filter((x) => x.id !== p.id && x.category === p.category)
    .concat(catalog.filter((x) => x.id !== p.id && x.category !== p.category))
    .slice(0, 4);
  relatedBox.innerHTML = related.map((x) => SB.cardHTML(x)).join("");
})();
